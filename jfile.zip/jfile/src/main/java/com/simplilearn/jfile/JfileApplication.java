package com.simplilearn.jfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(JfileApplication.class, args);
	}

}
